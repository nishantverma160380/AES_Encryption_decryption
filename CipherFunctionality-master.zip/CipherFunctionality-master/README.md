## CipherFunctionality
Visit the channel http://youtube.com/zarigatongy for the demo

### Feature Included 

### Learn Various Cipher Algorithms, and how to use them

__Cipher Algorithms, Encrytion Decryption__

1. Encrypt/Decrypt the Messages using the Algo
2. AES,DES,DESede,AES/CBC/PKCS5Padding (128)
3. AES/ECB/NoPadding (128)
4. AES/ECB/PKCS5Padding (128)
5. DES/CBC/NoPadding (56)
6. DES/CBC/PKCS5Padding (56)
7. DES/ECB/NoPadding (56)
8. DES/ECB/PKCS5Padding (56)
9. DESede/CBC/NoPadding (168)
10. DESede/CBC/PKCS5Padding (168)
11. DESede/ECB/NoPadding (168)
12. DESede/ECB/PKCS5Padding (168)

#### Get Alogorithm Capablities 
#### PEM Reader Decoder Online
#### Generate Message Digests
#### Create Self Sign Certificate 
#### Diffie Helman Key Exchange 
#### SSL Two Way Handshake Flow
#### PKI Fundamental


### String Functions

#### URL Encoders/Decoders
#### HexToString Conversion
#### StringToHex Conversion
#### Base64 Encode/Decode
#### Various String Functions
